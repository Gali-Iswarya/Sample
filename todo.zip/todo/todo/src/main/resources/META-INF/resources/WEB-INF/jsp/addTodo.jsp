<%@ include file="header.jsp" %>

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow-lg glass" style="width: 400px;">

        <h3 class="text-center mb-3">
            <i class="fa fa-plus-circle"></i> Add Todo
        </h3>

        <form action="add" method="post">
            <input name="title" class="form-control mb-3" placeholder="Title" required>

            <textarea name="description" class="form-control mb-3" placeholder="Description"></textarea>

            <input type="date" name="targetDate" class="form-control mb-3" required>

            <button class="btn btn-success w-100">
                Add Todo
            </button>
        </form>

        <a href="home" class="btn btn-light mt-3 w-100">Back</a>
    </div>
</div>