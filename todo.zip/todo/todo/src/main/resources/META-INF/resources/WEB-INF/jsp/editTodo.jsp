<%@ include file="header.jsp" %>

<div class="container mt-5">
    <div class="card p-4">

        <h3>Update Todo</h3>

        <form action="/update" method="post">

            <input type="hidden" name="id" value="${todo.id}"/>

            <input name="title" value="${todo.title}" class="form-control mb-2"/>
            <input name="description" value="${todo.description}" class="form-control mb-2"/>
            <input type="date" name="targetDate" value="${todo.targetDate}" class="form-control mb-2"/>

            <button class="btn btn-warning">Update</button>
        </form>

    </div>
</div>