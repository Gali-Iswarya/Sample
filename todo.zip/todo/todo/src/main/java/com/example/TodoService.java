package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoService {

    @Autowired
    private TodoRepository repo;

    public void save(Todo todo) {
        repo.save(todo);
    }

    public List<Todo> getTodos(User user) {
        return repo.findByUser(user);
    }

    public Todo getById(int id) {
        return repo.findById(id).orElse(null);
    }

    public void delete(int id) {
        repo.deleteById(id);
    }
}