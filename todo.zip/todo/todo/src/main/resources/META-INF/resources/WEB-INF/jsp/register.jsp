<%@ include file="header.jsp" %>

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow-lg glass" style="width: 350px;">
        <h3 class="text-center mb-3"><i class="fa fa-user-plus"></i> Register</h3>

        <form action="register" method="post">
            <input name="username" class="form-control mb-3" placeholder="Username" required>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

            <button class="btn btn-success w-100">Register</button>
        </form>

        <p class="text-center mt-3">
            Already have account? <a href="/" class="text-warning">Login</a>
        </p>
    </div>
</div>