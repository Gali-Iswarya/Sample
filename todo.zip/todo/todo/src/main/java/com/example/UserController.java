package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@SessionAttributes("user")
public class UserController {

    @Autowired
    private UserService service;

    @GetMapping("/")
    public String loginPage(Model m) {

        m.addAttribute("user", new User());

        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute User user,
                        Model m) {

        User dbUser = service.login(
                user.getUsername(),
                user.getPassword()
        );

        if (dbUser != null) {

            // REAL DATABASE USER
            m.addAttribute("user", dbUser);

            return "redirect:/home";
        }

        return "login";
    }

    @GetMapping("/register")
    public String registerPage(Model m) {

        m.addAttribute("user", new User());

        return "register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user) {

        service.register(user);

        return "redirect:/";
    }

    @GetMapping("/logout")
    public String logout(SessionStatus status) {

        status.setComplete();

        return "redirect:/";
    }
}