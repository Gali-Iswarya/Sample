package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public void register(User user) {
        repo.save(user);
    }

    public User login(String username, String password) {
        return repo.findByUsernameAndPassword(
                username,
                password
        );
    }

    public User getUserById(int id) {
        return repo.findById(id).orElse(null);
    }
}