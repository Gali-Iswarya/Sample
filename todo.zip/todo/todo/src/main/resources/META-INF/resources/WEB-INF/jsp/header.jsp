<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #667eea, #764ba2);
    font-family: 'Segoe UI', sans-serif;
}

.card {
    border-radius: 15px;
}

.btn {
    border-radius: 10px;
}

.navbar {
    background: rgba(0,0,0,0.7);
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    color: white;
}
</style>