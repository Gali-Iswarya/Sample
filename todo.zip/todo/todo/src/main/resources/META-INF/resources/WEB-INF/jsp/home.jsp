<%@ include file="header.jsp" %>

<nav class="navbar navbar-dark px-4">
    <span class="text-white">
        Hello ${user.username}
    </span>

    <div>
        <a href="add" class="btn btn-success btn-sm me-2">
            Add Todo
        </a>
        <a href="logout" class="btn btn-danger btn-sm">
            Logout
        </a>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">

        <c:forEach items="${todos}" var="t">
            <div class="col-md-4">
                <div class="card shadow-lg p-3 mb-4">

                    <h5>${t.title}</h5>
                    <p>${t.description}</p>
                    <p><b>${t.targetDate}</b></p>

                    <div class="d-flex justify-content-between">

                        <!-- UPDATE -->
                        <a href="edit/${t.id}" class="btn btn-warning btn-sm">
                            Update
                        </a>

                        <!-- DELETE -->
                        <a href="delete/${t.id}" class="btn btn-danger btn-sm">
                            Delete
                        </a>

                    </div>

                </div>
            </div>
        </c:forEach>

        <c:if test="${empty todos}">
            <h4 class="text-center text-white">No Todos Found</h4>
        </c:if>

    </div>
</div>