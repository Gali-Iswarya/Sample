package com.example;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TodoRepository
        extends JpaRepository<Todo, Integer> {

    List<Todo> findByUser(User user);
}