package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@SessionAttributes("user")
public class TodoController {

    @Autowired
    private TodoService service;

    @Autowired
    private UserService userService;

    // HOME
    @GetMapping("/home")
    public String home(
            @ModelAttribute("user") User sessionUser,
            Model m) {

        User user = userService.getUserById(
                sessionUser.getId()
        );

        m.addAttribute("todos",
                service.getTodos(user));

        return "home";
    }

    // ADD PAGE
    @GetMapping("/add")
    public String addPage(Model m) {

        m.addAttribute("todo", new Todo());

        return "addTodo";
    }

    // SAVE TODO
    @PostMapping("/add")
    public String add(
            @ModelAttribute Todo todo,
            @ModelAttribute("user") User sessionUser) {

        User user = userService.getUserById(
                sessionUser.getId()
        );

        todo.setUser(user);

        service.save(todo);

        return "redirect:/home";
    }

    // DELETE
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable int id) {

        service.delete(id);

        return "redirect:/home";
    }

    // EDIT PAGE
    @GetMapping("/edit/{id}")
    public String edit(
            @PathVariable int id,
            Model m) {

        Todo todo = service.getById(id);

        m.addAttribute("todo", todo);

        return "editTodo";
    }

    // UPDATE TODO
    @PostMapping("/update")
    public String update(
            @ModelAttribute Todo todo,
            @ModelAttribute("user") User sessionUser) {

        User user = userService.getUserById(
                sessionUser.getId()
        );

        todo.setUser(user);

        service.save(todo);

        return "redirect:/home";
    }
}