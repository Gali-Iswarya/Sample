<%@ include file="header.jsp" %>

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow-lg glass" style="width: 350px;">
        <h3 class="text-center mb-3"><i class="fa fa-user"></i> Login</h3>

        <form action="login" method="post">
            <input name="username" class="form-control mb-3" placeholder="Username" required>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

            <button class="btn btn-primary w-100">Login</button>
        </form>

        <p class="text-center mt-3">
            New user? <a href="register" class="text-warning">Register</a>
        </p>
    </div>
</div>